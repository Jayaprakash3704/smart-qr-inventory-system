import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './firebase.js';
import QRCode from 'qrcode';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import {
  collection,
  getDocs,
  updateDoc,
  doc,
  query,
  orderBy,
  getDoc,
  setDoc,
  deleteDoc,
  where,
  increment,
  limit,
} from 'firebase/firestore';

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Serve static files (React build)
const frontendPath = path.join(__dirname, 'public');
app.use(express.static(frontendPath));

// ─── HELPERS ────────────────────────────────────────────────────────────────

function generateProductId() {
  const year = new Date().getFullYear();
  const rand = Math.floor(10000 + Math.random() * 90000);
  return `PRD-${year}-${rand}`;
}

function generateTransactionId() {
  return `TXN-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}

async function createNotification(title, message, type = 'INFO') {
  const id = `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  await setDoc(doc(db, 'notifications', id), {
    id,
    title,
    message,
    type,
    isRead: false,
    createdAt: new Date().toISOString(),
  });
}

async function checkAndNotifyLowStock(product) {
  const threshold = product.low_stock_threshold ?? 5;
  if (product.quantity <= threshold && product.quantity >= 0) {
    await createNotification(
      '⚠️ Low Stock Alert',
      `"${product.name}" (SKU: ${product.sku}) has only ${product.quantity} ${product.unit || 'units'} remaining.`,
      'LOW_STOCK'
    );
  }
}

async function logScan(productId, action, details) {
  const scanId = `SCAN-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  await setDoc(doc(db, 'scanHistory', scanId), {
    productId,
    action,
    details,
    timestamp: new Date().toISOString(),
    scannedBy: 'SYSTEM_ADMIN',
  });
}

// ─── HEALTH ─────────────────────────────────────────────────────────────────

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'ScanTrack API is running', version: '2.0.0' });
});

// ─── PRODUCTS ────────────────────────────────────────────────────────────────

// List all products (optional search & category filter)
app.get('/api/products', async (req, res) => {
  try {
    const { search, category, status } = req.query;
    let q = query(collection(db, 'products'), orderBy('created_at', 'desc'));
    const snap = await getDocs(q);
    let products = snap.docs.map(d => ({ ...d.data(), firebaseId: d.id }));

    if (search) {
      const s = search.toLowerCase();
      products = products.filter(p =>
        (p.name || '').toLowerCase().includes(s) ||
        (p.sku || '').toLowerCase().includes(s) ||
        (p.category || '').toLowerCase().includes(s) ||
        (p.supplier || '').toLowerCase().includes(s)
      );
    }
    if (category) {
      products = products.filter(p =>
        (p.category || '').toLowerCase() === category.toLowerCase()
      );
    }
    if (status) {
      products = products.filter(p => (p.status || '').toUpperCase() === status.toUpperCase());
    }

    res.json(products);
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Get single product
app.get('/api/products/:id', async (req, res) => {
  try {
    const snap = await getDoc(doc(db, 'products', req.params.id));
    if (snap.exists()) return res.json(snap.data());
    res.status(404).json({ error: 'Product not found' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

// Create product
app.post('/api/products', async (req, res) => {
  try {
    const {
      name, sku, category, quantity, unit,
      location, supplier, low_stock_threshold, description, cost_price, sell_price
    } = req.body;

    if (!name) return res.status(400).json({ error: 'Product name is required' });

    const productId = generateProductId();
    const now = new Date().toISOString();
    const qty = parseInt(quantity) || 0;
    const threshold = parseInt(low_stock_threshold) || 5;

    let status = 'IN_STOCK';
    if (qty === 0) status = 'OUT_OF_STOCK';
    else if (qty <= threshold) status = 'LOW_STOCK';

    const productData = {
      id: productId,
      name: name.trim(),
      sku: sku || `SKU-${productId}`,
      category: category || 'General',
      quantity: qty,
      unit: unit || 'pcs',
      location: location || 'Warehouse',
      supplier: supplier || '',
      low_stock_threshold: threshold,
      description: description || '',
      cost_price: parseFloat(cost_price) || 0,
      sell_price: parseFloat(sell_price) || 0,
      status,
      created_at: now,
      updated_at: now,
    };

    await setDoc(doc(db, 'products', productId), productData);

    // Generate QR code image
    const qrDir = path.join(frontendPath, 'qrcodes');
    if (!fs.existsSync(qrDir)) fs.mkdirSync(qrDir, { recursive: true });

    const qrPayload = {
      id: productId,
      name: productData.name,
      sku: productData.sku,
      category: productData.category,
    };

    await QRCode.toFile(
      path.join(qrDir, `${productId}.png`),
      JSON.stringify(qrPayload),
      { color: { dark: '#1e293b', light: '#ffffff' }, width: 400, margin: 2 }
    );

    await logScan(productId, 'PRODUCT_CREATED', `${name} added to inventory`);

    if (qty <= threshold && qty > 0) {
      await checkAndNotifyLowStock(productData);
    }

    res.status(201).json(productData);
  } catch (err) {
    console.error('Error creating product:', err);
    res.status(500).json({ error: 'Failed to create product' });
  }
});

// Update product
app.put('/api/products/:id', async (req, res) => {
  try {
    const productId = req.params.id;
    const existing = await getDoc(doc(db, 'products', productId));
    if (!existing.exists()) return res.status(404).json({ error: 'Product not found' });

    const updates = { ...req.body, updated_at: new Date().toISOString() };
    delete updates.id;
    delete updates.created_at;
    delete updates.firebaseId;

    // Recalculate status if quantity changed
    if (updates.quantity !== undefined) {
      const threshold = updates.low_stock_threshold ?? existing.data().low_stock_threshold ?? 5;
      const qty = parseInt(updates.quantity) || 0;
      if (qty === 0) updates.status = 'OUT_OF_STOCK';
      else if (qty <= threshold) updates.status = 'LOW_STOCK';
      else updates.status = 'IN_STOCK';
    }

    await updateDoc(doc(db, 'products', productId), updates);
    const updated = await getDoc(doc(db, 'products', productId));
    res.json(updated.data());
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

// Delete product
app.delete('/api/products/:id', async (req, res) => {
  try {
    const productId = req.params.id;
    const snap = await getDoc(doc(db, 'products', productId));
    if (!snap.exists()) return res.status(404).json({ error: 'Product not found' });
    await deleteDoc(doc(db, 'products', productId));

    // Remove QR image if exists
    const qrPath = path.join(frontendPath, 'qrcodes', `${productId}.png`);
    if (fs.existsSync(qrPath)) fs.unlinkSync(qrPath);

    res.json({ success: true, message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// ─── STOCK IN ────────────────────────────────────────────────────────────────

app.post('/api/products/:id/stock-in', async (req, res) => {
  try {
    const productId = req.params.id;
    const { quantity, notes, supplier } = req.body;
    const qty = parseInt(quantity);

    if (!qty || qty <= 0) return res.status(400).json({ error: 'Valid quantity required' });

    const productSnap = await getDoc(doc(db, 'products', productId));
    if (!productSnap.exists()) return res.status(404).json({ error: 'Product not found' });

    const product = productSnap.data();
    const newQty = (product.quantity || 0) + qty;
    const threshold = product.low_stock_threshold ?? 5;

    let newStatus = 'IN_STOCK';
    if (newQty === 0) newStatus = 'OUT_OF_STOCK';
    else if (newQty <= threshold) newStatus = 'LOW_STOCK';

    const now = new Date().toISOString();
    await updateDoc(doc(db, 'products', productId), {
      quantity: newQty,
      status: newStatus,
      updated_at: now,
      ...(supplier ? { supplier } : {}),
    });

    // Record transaction
    const txnId = generateTransactionId();
    const txnData = {
      id: txnId,
      product_id: productId,
      product_name: product.name,
      sku: product.sku,
      type: 'STOCK_IN',
      quantity: qty,
      quantity_before: product.quantity || 0,
      quantity_after: newQty,
      notes: notes || '',
      performed_by: 'SYSTEM_ADMIN',
      timestamp: now,
    };
    await setDoc(doc(db, 'transactions', txnId), txnData);
    await logScan(productId, 'STOCK_IN', `+${qty} units added. New total: ${newQty}`);

    await createNotification(
      '📦 Stock In',
      `${qty} ${product.unit || 'units'} of "${product.name}" added. Total: ${newQty}`,
      'STOCK_IN'
    );

    res.json({ success: true, product_id: productId, new_quantity: newQty, transaction: txnData });
  } catch (err) {
    console.error('Stock-in error:', err);
    res.status(500).json({ error: 'Stock-in failed' });
  }
});

// ─── STOCK OUT ───────────────────────────────────────────────────────────────

app.post('/api/products/:id/stock-out', async (req, res) => {
  try {
    const productId = req.params.id;
    const { quantity, notes, reason } = req.body;
    const qty = parseInt(quantity);

    if (!qty || qty <= 0) return res.status(400).json({ error: 'Valid quantity required' });

    const productSnap = await getDoc(doc(db, 'products', productId));
    if (!productSnap.exists()) return res.status(404).json({ error: 'Product not found' });

    const product = productSnap.data();
    if ((product.quantity || 0) < qty) {
      return res.status(400).json({
        error: `Insufficient stock. Available: ${product.quantity || 0}, Requested: ${qty}`,
      });
    }

    const newQty = (product.quantity || 0) - qty;
    const threshold = product.low_stock_threshold ?? 5;
    let newStatus = 'IN_STOCK';
    if (newQty === 0) newStatus = 'OUT_OF_STOCK';
    else if (newQty <= threshold) newStatus = 'LOW_STOCK';

    const now = new Date().toISOString();
    await updateDoc(doc(db, 'products', productId), {
      quantity: newQty,
      status: newStatus,
      updated_at: now,
    });

    const txnId = generateTransactionId();
    const txnData = {
      id: txnId,
      product_id: productId,
      product_name: product.name,
      sku: product.sku,
      type: 'STOCK_OUT',
      quantity: qty,
      quantity_before: product.quantity || 0,
      quantity_after: newQty,
      reason: reason || 'Manual',
      notes: notes || '',
      performed_by: 'SYSTEM_ADMIN',
      timestamp: now,
    };
    await setDoc(doc(db, 'transactions', txnId), txnData);
    await logScan(productId, 'STOCK_OUT', `-${qty} units removed. New total: ${newQty}`);

    // Check for low stock / out of stock notifications
    const updatedProduct = { ...product, quantity: newQty, status: newStatus };
    await checkAndNotifyLowStock(updatedProduct);

    if (newQty === 0) {
      await createNotification(
        '🚨 Out of Stock',
        `"${product.name}" (SKU: ${product.sku}) is now OUT OF STOCK.`,
        'OUT_OF_STOCK'
      );
    }

    res.json({ success: true, product_id: productId, new_quantity: newQty, transaction: txnData });
  } catch (err) {
    console.error('Stock-out error:', err);
    res.status(500).json({ error: 'Stock-out failed' });
  }
});

// ─── QR CODES ────────────────────────────────────────────────────────────────

// Get QR code image for a product
app.get('/api/qr/:id', async (req, res) => {
  try {
    const productId = req.params.id;
    const qrPath = path.join(frontendPath, 'qrcodes', `${productId}.png`);

    // Regenerate if missing
    if (!fs.existsSync(qrPath)) {
      const snap = await getDoc(doc(db, 'products', productId));
      if (!snap.exists()) return res.status(404).json({ error: 'Product not found' });
      const product = snap.data();

      const qrDir = path.join(frontendPath, 'qrcodes');
      if (!fs.existsSync(qrDir)) fs.mkdirSync(qrDir, { recursive: true });

      await QRCode.toFile(qrPath, JSON.stringify({
        id: product.id,
        name: product.name,
        sku: product.sku,
        category: product.category,
      }), { color: { dark: '#1e293b', light: '#ffffff' }, width: 400, margin: 2 });
    }

    res.setHeader('Content-Type', 'image/png');
    res.sendFile(qrPath);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get QR code' });
  }
});

// QR scan decode → lookup product
app.post('/api/qr/scan', async (req, res) => {
  try {
    const { qr_data } = req.body;
    if (!qr_data) return res.status(400).json({ error: 'QR data required' });

    let productId = qr_data;
    try {
      const parsed = JSON.parse(qr_data);
      productId = parsed.id || qr_data;
    } catch (_) { /* treat as raw ID */ }

    const snap = await getDoc(doc(db, 'products', productId));
    if (!snap.exists()) return res.status(404).json({ error: 'Product not found', scanned: qr_data });

    await logScan(productId, 'QR_SCAN', `Product scanned via QR`);
    res.json(snap.data());
  } catch (err) {
    res.status(500).json({ error: 'QR scan lookup failed' });
  }
});

// ─── TRANSACTIONS ─────────────────────────────────────────────────────────────

app.get('/api/transactions', async (req, res) => {
  try {
    const { product_id, type, limit: lim } = req.query;
    let q = query(collection(db, 'transactions'), orderBy('timestamp', 'desc'));
    const snap = await getDocs(q);
    let txns = snap.docs.map(d => ({ ...d.data(), firebaseId: d.id }));

    if (product_id) txns = txns.filter(t => t.product_id === product_id);
    if (type) txns = txns.filter(t => t.type === type.toUpperCase());

    const n = parseInt(lim) || 100;
    res.json(txns.slice(0, n));
  } catch (err) {
    res.json([]);
  }
});

// ─── ORDERS ──────────────────────────────────────────────────────────────────

app.get('/api/orders', async (req, res) => {
  try {
    const q = query(collection(db, 'orders'), orderBy('created_at', 'desc'));
    const snap = await getDocs(q);
    res.json(snap.docs.map(d => d.data()));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const { customer_name, items, notes } = req.body;
    if (!customer_name || !items || !items.length) {
      return res.status(400).json({ error: 'Customer name and items are required' });
    }

    const orderId = `ORD-${Date.now()}`;
    const now = new Date().toISOString();
    const orderData = {
      id: orderId,
      customer_name,
      items,
      notes: notes || '',
      status: 'PENDING',
      created_at: now,
      updated_at: now,
      approved_at: null,
    };

    await setDoc(doc(db, 'orders', orderId), orderData);

    const itemsSummary = items.map(i => `${i.quantity}x ${i.product_name || i.product_id}`).join(', ');
    await createNotification(
      '🛒 New Order',
      `Order from ${customer_name}: ${itemsSummary}`,
      'ORDER_PENDING'
    );

    res.status(201).json(orderData);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create order' });
  }
});

app.post('/api/orders/:id/approve', async (req, res) => {
  try {
    const orderId = req.params.id;
    const orderSnap = await getDoc(doc(db, 'orders', orderId));
    if (!orderSnap.exists()) return res.status(404).json({ error: 'Order not found' });

    const order = orderSnap.data();
    if (order.status !== 'PENDING') {
      return res.status(400).json({ error: `Order is already ${order.status}` });
    }

    // Check stock availability for each item
    const insufficient = [];
    for (const item of order.items) {
      const snap = await getDoc(doc(db, 'products', item.product_id));
      if (!snap.exists() || snap.data().quantity < item.quantity) {
        insufficient.push({
          product_id: item.product_id,
          name: item.product_name,
          required: item.quantity,
          available: snap.exists() ? snap.data().quantity : 0,
        });
      }
    }

    if (insufficient.length > 0) {
      return res.status(400).json({ error: 'Insufficient stock', details: insufficient });
    }

    const now = new Date().toISOString();
    // Deduct stock for each item
    for (const item of order.items) {
      const productSnap = await getDoc(doc(db, 'products', item.product_id));
      const product = productSnap.data();
      const newQty = product.quantity - item.quantity;
      const threshold = product.low_stock_threshold ?? 5;
      let newStatus = 'IN_STOCK';
      if (newQty === 0) newStatus = 'OUT_OF_STOCK';
      else if (newQty <= threshold) newStatus = 'LOW_STOCK';

      await updateDoc(doc(db, 'products', item.product_id), {
        quantity: newQty, status: newStatus, updated_at: now,
      });

      const txnId = generateTransactionId();
      await setDoc(doc(db, 'transactions', txnId), {
        id: txnId,
        product_id: item.product_id,
        product_name: product.name,
        sku: product.sku,
        type: 'STOCK_OUT',
        quantity: item.quantity,
        quantity_before: product.quantity,
        quantity_after: newQty,
        reason: `Order ${orderId}`,
        notes: `Approved order for ${order.customer_name}`,
        performed_by: 'SYSTEM_ADMIN',
        timestamp: now,
      });

      await checkAndNotifyLowStock({ ...product, quantity: newQty });
    }

    await updateDoc(doc(db, 'orders', orderId), {
      status: 'APPROVED',
      approved_at: now,
      updated_at: now,
    });

    await createNotification(
      '✅ Order Approved',
      `Order ${orderId} for ${order.customer_name} has been approved and fulfilled.`,
      'ORDER_APPROVED'
    );

    res.json({ success: true, message: `Order ${orderId} approved and stock deducted` });
  } catch (err) {
    console.error('Approve order error:', err);
    res.status(500).json({ error: 'Failed to approve order' });
  }
});

app.post('/api/orders/:id/cancel', async (req, res) => {
  try {
    const orderId = req.params.id;
    const snap = await getDoc(doc(db, 'orders', orderId));
    if (!snap.exists()) return res.status(404).json({ error: 'Order not found' });

    const order = snap.data();
    if (order.status === 'APPROVED') {
      return res.status(400).json({ error: 'Cannot cancel an already approved order' });
    }

    await updateDoc(doc(db, 'orders', orderId), {
      status: 'CANCELLED',
      updated_at: new Date().toISOString(),
    });
    res.json({ success: true, message: 'Order cancelled' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to cancel order' });
  }
});

// ─── NOTIFICATIONS ───────────────────────────────────────────────────────────

app.get('/api/notifications', async (req, res) => {
  try {
    const snap = await getDocs(collection(db, 'notifications'));
    const notifs = snap.docs.map(d => ({ ...d.data(), id: d.id }));
    notifs.sort((a, b) => new Date(b.createdAt || b.created_at || 0) - new Date(a.createdAt || a.created_at || 0));
    res.json(notifs);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch notifications' });
  }
});

app.post('/api/notifications/mark-all-read', async (req, res) => {
  try {
    const snap = await getDocs(collection(db, 'notifications'));
    const unread = snap.docs.filter(d => !d.data().isRead);
    await Promise.all(unread.map(d => updateDoc(d.ref, { isRead: true })));
    res.json({ success: true, marked: unread.length });
  } catch (err) {
    res.status(500).json({ error: 'Failed to mark notifications as read' });
  }
});

app.delete('/api/notifications/:id', async (req, res) => {
  try {
    await deleteDoc(doc(db, 'notifications', req.params.id));
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete notification' });
  }
});

// ─── REPORTS ─────────────────────────────────────────────────────────────────

app.get('/api/reports/summary', async (req, res) => {
  try {
    const [productsSnap, txnsSnap, ordersSnap] = await Promise.all([
      getDocs(collection(db, 'products')),
      getDocs(collection(db, 'transactions')),
      getDocs(collection(db, 'orders')),
    ]);

    const products = productsSnap.docs.map(d => d.data());
    const txns = txnsSnap.docs.map(d => d.data());
    const orders = ordersSnap.docs.map(d => d.data());

    const totalProducts = products.length;
    const inStock = products.filter(p => p.status === 'IN_STOCK').length;
    const lowStock = products.filter(p => p.status === 'LOW_STOCK').length;
    const outOfStock = products.filter(p => p.status === 'OUT_OF_STOCK').length;
    const totalQuantity = products.reduce((s, p) => s + (p.quantity || 0), 0);

    const stockInQty = txns.filter(t => t.type === 'STOCK_IN').reduce((s, t) => s + (t.quantity || 0), 0);
    const stockOutQty = txns.filter(t => t.type === 'STOCK_OUT').reduce((s, t) => s + (t.quantity || 0), 0);

    const pendingOrders = orders.filter(o => o.status === 'PENDING').length;
    const approvedOrders = orders.filter(o => o.status === 'APPROVED').length;

    // Category breakdown
    const categoryMap = {};
    products.forEach(p => {
      const cat = p.category || 'General';
      categoryMap[cat] = (categoryMap[cat] || 0) + 1;
    });
    const categoryBreakdown = Object.entries(categoryMap).map(([name, count]) => ({ name, count }));

    // Status breakdown
    const statusBreakdown = [
      { name: 'In Stock', count: inStock },
      { name: 'Low Stock', count: lowStock },
      { name: 'Out of Stock', count: outOfStock },
    ];

    // Daily transactions (last 7 days)
    const now = Date.now();
    const sevenDaysAgo = now - 7 * 24 * 60 * 60 * 1000;
    const recentTxns = txns.filter(t => new Date(t.timestamp).getTime() > sevenDaysAgo);
    const dailyMap = {};
    recentTxns.forEach(t => {
      const day = t.timestamp ? t.timestamp.substring(0, 10) : 'Unknown';
      if (!dailyMap[day]) dailyMap[day] = { date: day, stockIn: 0, stockOut: 0 };
      if (t.type === 'STOCK_IN') dailyMap[day].stockIn += t.quantity || 0;
      if (t.type === 'STOCK_OUT') dailyMap[day].stockOut += t.quantity || 0;
    });
    const dailyTransactions = Object.values(dailyMap).sort((a, b) => a.date.localeCompare(b.date));

    // Top products by activity
    const productActivity = {};
    txns.forEach(t => {
      if (!productActivity[t.product_id]) {
        productActivity[t.product_id] = { name: t.product_name || t.product_id, count: 0 };
      }
      productActivity[t.product_id].count++;
    });
    const topProducts = Object.values(productActivity)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    res.json({
      totalProducts,
      inStock,
      lowStock,
      outOfStock,
      totalQuantity,
      stockInQty,
      stockOutQty,
      pendingOrders,
      approvedOrders,
      totalOrders: orders.length,
      categoryBreakdown,
      statusBreakdown,
      dailyTransactions,
      topProducts,
    });
  } catch (err) {
    console.error('Reports error:', err);
    res.status(500).json({ error: 'Failed to generate report' });
  }
});

app.get('/api/reports/low-stock', async (req, res) => {
  try {
    const snap = await getDocs(collection(db, 'products'));
    const lowStockProducts = snap.docs
      .map(d => d.data())
      .filter(p => p.status === 'LOW_STOCK' || p.status === 'OUT_OF_STOCK')
      .sort((a, b) => (a.quantity || 0) - (b.quantity || 0));
    res.json(lowStockProducts);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch low stock' });
  }
});

// ─── CATCH-ALL SPA ROUTE ─────────────────────────────────────────────────────

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found' });
  }
  const indexFile = path.join(frontendPath, 'index.html');
  if (fs.existsSync(indexFile)) {
    res.sendFile(indexFile);
  } else {
    res.status(503).send('<h2>Frontend not built yet. Run: npm run build inside web/</h2>');
  }
});

// ─── START ───────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log('\n🚀 ═══════════════════════════════════════════════════════');
  console.log('   ScanTrack QR Inventory — API Server v2.0');
  console.log(`   📡 Running on: http://localhost:${PORT}`);
  console.log('   ═══════════════════════════════════════════════════════\n');
});
